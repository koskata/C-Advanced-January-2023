﻿using System.Text;

namespace ComputerArchitecture
{
    public class Computer
    {
        private string model;
        private int capacity;
        private List<CPU> multiprocessor;

        public Computer(string model, int capacity)
        {
            Model = model;
            Capacity = capacity;
            Multiprocessor = new List<CPU>();
        }

        public int Count
        {
            get
            {
                return Multiprocessor.Count;
            }

        }

        public string Model { get; set; }
        public int Capacity { get; set; }

        public List<CPU> Multiprocessor { get; set; }


        public void Add(CPU cpu)
        {
            if (Count < Capacity)
            {
                Multiprocessor.Add(cpu);
            }
        }

        public bool Remove(string brand)
        {
            CPU cpuToRemove = Multiprocessor.FirstOrDefault(x => x.Brand == brand);
            if (cpuToRemove != null)
            {
                return Multiprocessor.Remove(cpuToRemove);
            }

            return false;
        }

        public CPU MostPowerful()
        {
            CPU cpu = Multiprocessor.MaxBy(x => x.Frequency);

            return cpu;
        }

        public CPU GetCPU(string brand) 
        {
            CPU cpu = Multiprocessor.FirstOrDefault(x => x.Brand == brand);

            if (cpu != null)
            {
                return cpu;
            }

            return null;
        }

        public string Report() 
        {
            StringBuilder sb = new();

            sb.AppendLine($"CPUs in the Computer {Model}:");
            foreach (var pc in Multiprocessor)
            {
                sb.AppendLine(pc.ToString());
            }

            return sb.ToString();
        }

    }
}

